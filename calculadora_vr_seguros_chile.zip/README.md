# 🏢 Calculadora de Valor de Reconstrucción — Seguros Chile

Aplicación web para calcular el **valor de reconstrucción** de inmuebles en Chile,
conforme a la normativa vigente: DFL 251 · DS 1055 · CCom art. 553 · Ley 21.442 · NCG 556 CMF (dic. 2025).

---

## 🚀 Despliegue en Streamlit Cloud (recomendado)

### Paso 1 — Subir a GitHub

1. Cree un repositorio nuevo en [github.com](https://github.com/) (puede ser público o privado).
2. Suba estos archivos manteniendo exactamente esta estructura:

```
mi-repositorio/
├── app.py
├── requirements.txt
└── .streamlit/
    └── config.toml
```

> **Importante:** la carpeta `.streamlit/` debe ir en la raíz del repositorio.

### Paso 2 — Conectar con Streamlit Cloud

1. Vaya a [share.streamlit.io](https://share.streamlit.io/) e inicie sesión con su cuenta de GitHub.
2. Haga clic en **"New app"**.
3. Seleccione su repositorio y rama (`main` o `master`).
4. En **"Main file path"** escriba: `app.py`
5. Haga clic en **"Deploy"**.

La aplicación estará disponible en una URL del tipo:
`https://tu-usuario-streamlit-app.streamlit.app`

### Paso 3 — Google Maps (opcional)

Si desea activar la geocodificación automática de direcciones:

1. En Streamlit Cloud, vaya a **Settings → Secrets** de su app.
2. Agregue:
```toml
GOOGLE_MAPS_API_KEY = "AIzaSy..."
```
3. Obtenga la clave en [console.cloud.google.com](https://console.cloud.google.com/) habilitando la API **Geocoding API**.

Sin esta clave la app funciona igual — solo los botones de Google Earth y Google Maps estarán disponibles en vez del mapa integrado.

---

## 💻 Correr localmente

### Requisitos
- Python 3.9 o superior
- pip

### Instalación

```bash
# Clonar el repositorio
git clone https://github.com/tu-usuario/tu-repositorio.git
cd tu-repositorio

# Instalar dependencias
pip install -r requirements.txt

# Correr la aplicación
streamlit run app.py
```

La app se abrirá automáticamente en `http://localhost:8501`

---

## 📋 Funcionalidades

### Tipos de análisis
| Modo | Descripción |
|------|-------------|
| 🏠 **Inmueble completo** | Casas, locales o edificio en bloque (una póliza para todo) |
| 🏛️ **Solo bienes comunes** | Póliza obligatoria de la comunidad (Ley 21.442 art. 43) |
| 🏢 **Comunidad completa** | Bienes comunes + unidades privadas separadas (NCG 556 CMF, dos bloques) |

### Características principales
- ✅ **Cálculo de VR** con factores geográfico, normativo y de altura
- ✅ **Valor a nuevo vs. valor real depreciado** con 4 métodos de depreciación:
  - Ross-Heidecke (recomendado seguros)
  - Tabla MINVU / DS 1101 (oficial)
  - Línea recta por vida útil
  - Manual / criterio profesional
- ✅ **Superficies por porcentaje o conocidas directamente**
- ✅ **Calculadora de superficies** en sidebar (mide por zonas desde Google Earth)
- ✅ **Ingreso masivo de unidades** por plantilla Excel
- ✅ **Simulación de siniestro** por % o pérdida real en UF
- ✅ **Informes** en TXT y Word (.docx)
- ✅ **Formato numérico chileno** (punto=miles, coma=decimal)

---

## ⚖️ Marco normativo

| Norma | Contenido |
|-------|-----------|
| **DFL 251** | Ley de Compañías de Seguros |
| **DS 1055** | Reglamento de seguros de incendio |
| **CCom art. 553** | Regla proporcional (infraseguro) |
| **Ley 21.442** | Copropiedad inmobiliaria — seguro obligatorio bienes comunes |
| **NCG 556 CMF** | Estructura póliza colectiva (dic. 2025) |

---

## 📁 Estructura del repositorio

```
├── app.py                  # Aplicación principal Streamlit
├── requirements.txt        # Dependencias Python
├── .streamlit/
│   └── config.toml         # Tema y configuración de Streamlit
└── README.md               # Este archivo
```

---

## ⚠️ Aviso legal

Programa de carácter **referencial**. Los valores calculados no reemplazan una tasación profesional
ni la asesoría de un corredor de seguros certificado. Para cada caso específico consulte a un
tasador habilitado o corredor de seguros autorizado por la CMF.

Fuente VUB oficial: [Tabla MINVU](https://www.minvu.gob.cl/elementos-tecnicos/tabla-de-costos-unitarios/)
